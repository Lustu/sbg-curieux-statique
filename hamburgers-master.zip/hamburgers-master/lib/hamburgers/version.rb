module Hamburgers
  VERSION = "0.8.1"
end
